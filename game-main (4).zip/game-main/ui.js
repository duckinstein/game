import { globals, tryLoadImage } from './globals.js';

// --- 1. ASSET LOADERS ---
export const uiSheet = { image: null, ready: false };
export const playerHealthSheet = { image: null, ready: false, frames: [] };
export const enemyHealthSheet = { image: null, ready: false, frames: [] };
export const attackBtnSheet = { image: null, ready: false };

tryLoadImage(["./ui.png", "./UI.png", "./buttons.png", "./controls.png"], (img) => {
  uiSheet.image = img;
  uiSheet.ready = true;
  updateUIElements();
});

tryLoadImage(["./0-health bar.png", "./0-health_bar.png", "./0-healthbar.png", "./healthbar_0.png"], (img) => {
  playerHealthSheet.image = img;
  playerHealthSheet.ready = true;
  updatePlayerHUDHealth(100, 100);
});

tryLoadImage(["./7-health bar.png", "./7-health_bar.png", "./7-healthbar.png", "./healthbar_7.png"], (img) => {
  enemyHealthSheet.image = img;
  enemyHealthSheet.ready = true;
});

tryLoadImage(["./attack_btn.png", "./attack_button.png", "./sword.png", "./attack.png"], (img) => {
  attackBtnSheet.image = img;
  attackBtnSheet.ready = true;
  updateAttackButton();
});

// --- 2. PIXEL-ART GENERATORS & SLICERS ---
function createPixelCanvas(w, h) {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const ctx = c.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  return { canvas: c, ctx };
}

// Procedural Arrow generator matching Image 1
export function generateArrowSprite(dir) {
  const { canvas, ctx } = createPixelCanvas(32, 32);

  if (uiSheet.ready && uiSheet.image) {
    const sw = uiSheet.image.naturalWidth / 3;
    const sh = uiSheet.image.naturalHeight / 3;
    let col = 0, row = 0;
    if (dir === "down")  { col = 0; row = 0; }
    if (dir === "right") { col = 1; row = 0; }
    if (dir === "up")    { col = 2; row = 0; }
    if (dir === "left")  { col = 0; row = 1; }
    ctx.drawImage(uiSheet.image, col * sw, row * sh, sw, sh, 0, 0, 32, 32);
    return canvas.toDataURL();
  }

  // Exact pixel fallback matching sprite
  ctx.save();
  ctx.translate(16, 16);
  if (dir === "right") ctx.rotate(Math.PI / 2);
  if (dir === "up")    ctx.rotate(Math.PI);
  if (dir === "left")  ctx.rotate(-Math.PI / 2);

  // Shadow / bottom 3D bevel
  ctx.fillStyle = "#843e26";
  ctx.beginPath();
  ctx.moveTo(-6, -11); ctx.lineTo(6, -11); ctx.lineTo(6, 1);
  ctx.lineTo(13, 1); ctx.lineTo(0, 14); ctx.lineTo(-13, 1); ctx.lineTo(-6, 1);
  ctx.closePath(); ctx.fill();

  // Face / top fill
  ctx.fillStyle = "#c37b58";
  ctx.beginPath();
  ctx.moveTo(-6, -11); ctx.lineTo(6, -11); ctx.lineTo(6, 0);
  ctx.lineTo(13, 0); ctx.lineTo(0, 12); ctx.lineTo(-13, 0); ctx.lineTo(-6, 0);
  ctx.closePath(); ctx.fill();

  // Outline
  ctx.strokeStyle = "#431c0e";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();

  return canvas.toDataURL();
}

// Attack Button: Circular brown button with dark brown sword inside
export function generateAttackButtonSprite() {
  const { canvas, ctx } = createPixelCanvas(64, 64);

  // 1. Draw circular brown button
  if (uiSheet.ready && uiSheet.image) {
    const sw = uiSheet.image.naturalWidth / 3;
    const sh = uiSheet.image.naturalHeight / 3;
    ctx.drawImage(uiSheet.image, 1 * sw, 1 * sh, sw, sh, 2, 2, 60, 60);
  } else {
    // 3D Bevel bottom
    ctx.fillStyle = "#843e26";
    ctx.beginPath();
    ctx.arc(32, 34, 28, 0, Math.PI * 2);
    ctx.fill();

    // Main surface
    ctx.fillStyle = "#c37b58";
    ctx.beginPath();
    ctx.arc(32, 31, 28, 0, Math.PI * 2);
    ctx.fill();

    // Dark brown pixel border
    ctx.strokeStyle = "#431c0e";
    ctx.lineWidth = 3;
    ctx.stroke();
  }

  // 2. Draw dark brown slashing sword inside
  ctx.save();
  ctx.translate(32, 31);

  // Dark brown sword & slash trail
  ctx.fillStyle = "#361408";
  ctx.strokeStyle = "#361408";
  ctx.lineWidth = 3;
  ctx.lineCap = "round";

  // Slash arc
  ctx.beginPath();
  ctx.arc(0, 0, 16, -Math.PI * 0.7, Math.PI * 0.4);
  ctx.stroke();

  // Sword blade
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(-10, -10);
  ctx.lineTo(10, 10);
  ctx.stroke();

  // Crossguard
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(-13, -7);
  ctx.lineTo(-7, -13);
  ctx.stroke();

  // Hilt
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(-10, -10);
  ctx.lineTo(-14, -14);
  ctx.stroke();

  ctx.restore();
  return canvas.toDataURL();
}

// Gold Coin Sprite
export function generateCoinSprite() {
  const { canvas, ctx } = createPixelCanvas(28, 28);

  if (uiSheet.ready && uiSheet.image) {
    const sw = uiSheet.image.naturalWidth / 3;
    const sh = uiSheet.image.naturalHeight / 3;
    ctx.drawImage(uiSheet.image, 1 * sw, 2 * sh, sw, sh, 0, 0, 28, 28);
    return canvas.toDataURL();
  }

  // Fallback coin
  ctx.fillStyle = "#431c0e";
  ctx.beginPath(); ctx.arc(14, 14, 12, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = "#f8b724";
  ctx.beginPath(); ctx.arc(14, 14, 10, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = "#ffe266";
  ctx.beginPath(); ctx.arc(13, 13, 7, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = "#b8720e";
  ctx.fillRect(13, 10, 3, 8);
  return canvas.toDataURL();
}

// Updates HTML UI elements
export function updateUIElements() {
  document.querySelectorAll("[data-dir]").forEach(btn => {
    const dir = btn.dataset.dir;
    btn.style.backgroundImage = `url("${generateArrowSprite(dir)}")`;
  });

  const coinIcon = document.getElementById("coin-icon-img");
  if (coinIcon) coinIcon.src = generateCoinSprite();

  updateAttackButton();
}

export function updateAttackButton() {
  const attackBtn = document.getElementById("attack");
  if (attackBtn) {
    attackBtn.style.backgroundImage = `url("${generateAttackButtonSprite()}")`;
  }
}

// --- 3. HEALTH BARS (0-health bar & 7-health bar) ---
export function updatePlayerHUDHealth(currentHp, maxHp) {
  const canvas = document.getElementById("player-health-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const ratio = Math.max(0, Math.min(1, currentHp / maxHp));
  const stages = 5;
  const stage = Math.min(stages - 1, Math.floor((1 - ratio) * stages));

  // If 0-health bar.png loaded
  if (playerHealthSheet.ready && playerHealthSheet.image) {
    const img = playerHealthSheet.image;
    // Supports 5 vertical frames (or horizontal)
    if (img.naturalHeight > img.naturalWidth) {
      const sh = img.naturalHeight / 5;
      ctx.drawImage(img, 0, stage * sh, img.naturalWidth, sh, 0, 0, canvas.width, canvas.height);
    } else {
      const sw = img.naturalWidth / 5;
      ctx.drawImage(img, stage * sw, 0, sw, img.naturalHeight, 0, 0, canvas.width, canvas.height);
    }
    return;
  }

  // Fallback 0-health bar matching Image 3
  const heartW = 20, barW = canvas.width - heartW - 4, barH = 14;
  const barX = heartW + 2, barY = 6;

  // Heart icon with highlight
  ctx.fillStyle = "#e62238";
  ctx.beginPath();
  ctx.moveTo(10, 5);
  ctx.bezierCurveTo(10, 2, 5, 2, 5, 6);
  ctx.bezierCurveTo(5, 11, 10, 16, 10, 19);
  ctx.bezierCurveTo(10, 16, 15, 11, 15, 6);
  ctx.bezierCurveTo(15, 2, 10, 2, 10, 5);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(7, 5, 2, 2);

  // Bar outline & fill
  ctx.fillStyle = "#1b191c";
  ctx.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);
  ctx.fillStyle = "#3a3942";
  ctx.fillRect(barX, barY, barW, barH);

  const fillW = Math.round(barW * ratio);
  if (fillW > 0) {
    ctx.fillStyle = "#e62238";
    ctx.fillRect(barX, barY, fillW, barH);
    ctx.fillStyle = "#ff7d8d";
    ctx.fillRect(barX, barY, fillW, 2);
  }
}

// 7-health bar for enemy overhead health
export function drawEnemyHealthBar(ctx, screenX, screenY, ratio) {
  const barW = Math.round(globals.tile * 0.9);
  const barH = 7;
  const barX = Math.round(screenX - barW / 2);
  const barY = Math.round(screenY);

  const stages = 5;
  const stage = Math.min(stages - 1, Math.floor((1 - ratio) * stages));

  // If 7-health bar.png loaded
  if (enemyHealthSheet.ready && enemyHealthSheet.image) {
    const img = enemyHealthSheet.image;
    if (img.naturalHeight > img.naturalWidth) {
      const sh = img.naturalHeight / 5;
      ctx.drawImage(img, 0, stage * sh, img.naturalWidth, sh, barX, barY, barW, barH);
    } else {
      const sw = img.naturalWidth / 5;
      ctx.drawImage(img, stage * sw, 0, sw, img.naturalHeight, barX, barY, barW, barH);
    }
    return;
  }

  // Fallback segmented 7-health bar matching Image 2
  ctx.fillStyle = "#0c0404";
  ctx.fillRect(barX - 1, barY - 1, barW + 2, barH + 2);
  ctx.fillStyle = "#4a494d";
  ctx.fillRect(barX, barY, barW, barH);

  const segments = 4;
  const segW = Math.floor((barW - (segments - 1)) / segments);
  const filledSegs = Math.round(ratio * segments);

  for (let s = 0; s < segments; s++) {
    const sx = barX + s * (segW + 1);
    if (s < filledSegs) {
      ctx.fillStyle = "#e62238";
      ctx.fillRect(sx, barY, segW, barH);
      ctx.fillStyle = "#ff7d8d";
      ctx.fillRect(sx, barY, segW, 1);
    }
  }

  // Small heart indicator on left
  ctx.fillStyle = "#e62238";
  ctx.fillRect(barX - 6, barY + 1, 4, 5);
}
